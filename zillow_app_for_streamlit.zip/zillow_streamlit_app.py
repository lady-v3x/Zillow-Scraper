import streamlit as st
import pandas as pd
from io import BytesIO
from PIL import Image
import re
from playwright.sync_api import sync_playwright
import requests

st.set_page_config(page_title="Zillow Scraper App")
st.title("Zillow Listing Extractor 🏡")

st.markdown("Paste Zillow links below (one per line). We'll extract key details and group by location.")

zillow_input = st.text_area("Zillow Links")

def extract_data_from_zillow(url):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url, timeout=60000)
        page.wait_for_timeout(3000)

        try:
            price = page.query_selector("span[data-testid='price']").inner_text()
        except:
            price = "N/A"

        try:
            bed_elem = page.query_selector_all("span[data-testid='bed-bath-item']")
            beds = bed_elem[0].inner_text().split()[0] if bed_elem else "N/A"
            baths = bed_elem[1].inner_text().split()[0] if len(bed_elem) > 1 else "N/A"
            sqft = bed_elem[2].inner_text() if len(bed_elem) > 2 else "N/A"
        except:
            beds = baths = sqft = "N/A"

        try:
            city_state = page.query_selector("h1[data-testid='home-details-summary-headline']").inner_text()
            if "," in city_state:
                parts = city_state.split(",")
                city, state = parts[0].strip(), parts[1].strip()
            else:
                city, state = "N/A", "N/A"
        except:
            city, state = "N/A", "N/A"

        try:
            thumbnail = page.query_selector("meta[property='og:image']").get_attribute("content")
        except:
            thumbnail = None

        browser.close()

        return {
            "URL": url,
            "Price": price,
            "Beds": beds,
            "Baths": baths,
            "Square Feet": sqft,
            "City": city,
            "State": state,
            "High School": "Coming soon",
            "School Rating": "Coming soon",
            "Thumbnail": thumbnail
        }

if st.button("Fetch Listings"):
    with st.spinner("Extracting data from Zillow links..."):
        links = zillow_input.strip().split("\n")
        listings = [extract_data_from_zillow(link.strip()) for link in links if link.strip()]

        df = pd.DataFrame(listings)

        if not df.empty:
            st.success("Listings extracted!")
            st.dataframe(df.drop(columns=["Thumbnail"]))

            for i, row in df.iterrows():
                st.markdown(f"**{row['City']}, {row['State']} — {row['Price']}**")
                if row['Thumbnail']:
                    try:
                        img_data = requests.get(row['Thumbnail']).content
                        st.image(Image.open(BytesIO(img_data)), width=300)
                    except:
                        st.warning("Thumbnail failed to load.")

            excel_buffer = BytesIO()
            df.drop(columns=['Thumbnail']).to_excel(excel_buffer, index=False)
            st.download_button("Download Excel File", excel_buffer.getvalue(), file_name="zillow_grouped_listings.xlsx")
        else:
            st.warning("No valid listings extracted.")